import json
import boto3

def lambda_handler(event, context):
    try:
        client = boto3.client('ec2')
        cp_client = boto3.client('codepipeline')
        response = client.describe_images(
            Filters=[
                {
                    'Name': 'name',
                    'Values': [
                        'Custom_EC2_Image',
                    ]
                },
            ],
        )
        ami_id = response['Images'][0]['ImageId']
        ssm_client = boto3.client('ssm')
        response = ssm_client.put_parameter(
            Name='latest_ami_id',
            Value=ami_id,
            Type='String',
            Overwrite=True
        )
        codepipeline_job_id = event["CodePipeline.job"]["id"]
        codepipeline_revision = event['CodePipeline.job']['data']['inputArtifacts'][0]['revision']
        cp_client.put_job_success_result(
            jobId=codepipeline_job_id,
            currentRevision={
                'revision': codepipeline_revision,
                'changeIdentifier': '7337'
            }
        )
    except:
        print("failed")
        cp_client = boto3.client('codepipeline')
        cp_client.put_job_failure_result(
            jobId=event["CodePipeline.job"]["id"],
            failureDetails={
                'type': 'JobFailed',
                'message': 'failed'
            }
        )
