import json
import boto3

def get_parameter(client, param):
    response = client.get_parameter(
        Name=param
    )
    return response["Parameter"]["Value"]

def lambda_handler(event, context):
    client = boto3.client('ssm')
    latest_ami_id = get_parameter(client, "latest_ami_id")
    latest_ami_subnet = get_parameter(client, "latest_ami_subnet")
    latest_ami_securitygroup = get_parameter(client, "latest_ami_securitygroup")
    latest_ami_instance_profile_name = get_parameter(client, "latest_ami_instance_profile_name")
    latest_ami_ssm_service_role = get_parameter(client, "latest_ami_ssm_service_role")
    response = client.start_automation_execution(
        DocumentName='Patch-Linux-AMI',
        Parameters={
            'SourceAmiId': [
                latest_ami_id,
            ],
            'SubnetId': [
                latest_ami_subnet,
            ],
            'SecurityGroupId': [
                latest_ami_securitygroup,
            ],
            'IamInstanceProfileName': [
                latest_ami_instance_profile_name,
            ],
            'AutomationAssumeRole': [
                latest_ami_ssm_service_role,
            ],
            'TargetAmiName': [
                "Custom-AMI-{{global:DATE_TIME}}",
            ]
        }
    )
    print(response)