import boto3

def lambda_handler(event, context):
    ec2_client = boto3.client('ec2')
    ssm_client = boto3.client('ssm')
    cp_client = boto3.client('codepipeline')

    print(event)
    response = ssm_client.get_parameter(Name='latest_ami_id')
    latest_ami_id = response["Parameter"]["Value"]
    print("Latest AMI ID: " + latest_ami_id)

    response = ec2_client.describe_launch_template_versions(LaunchTemplateName='Auto-Scaling-Launch-Template')
    launch_template_versions = response["LaunchTemplateVersions"]
    latest_launch_template_version = launch_template_versions[0]["VersionNumber"]
    print("Current Launch Template Version: " + str(latest_launch_template_version))

    response = ec2_client.create_launch_template_version(
        LaunchTemplateName='Auto-Scaling-Launch-Template',
        SourceVersion=str(latest_launch_template_version),
        LaunchTemplateData={
            'ImageId': latest_ami_id
        }
    )
    print("New Launch Template Version " + str(response["LaunchTemplateVersion"]["VersionNumber"]) + " created for " + response["LaunchTemplateVersion"]["LaunchTemplateId"])

    ec2_client.modify_launch_template(
        LaunchTemplateName='Auto-Scaling-Launch-Template',
        DefaultVersion=str(response["LaunchTemplateVersion"]["VersionNumber"])
    )
    if event:
        try:
            codepipeline_job_id = event["CodePipeline.job"]["id"]
            codepipeline_revision = event['CodePipeline.job']['data']['inputArtifacts'][0]['revision']
            cp_client.put_job_success_result(
                jobId=codepipeline_job_id,
                currentRevision={
                    'revision': codepipeline_revision,
                    'changeIdentifier': '7337'
                }
            )
        except:
            print("failed")
            cp_client = boto3.client('codepipeline')
            cp_client.put_job_failure_result(
                jobId=event["CodePipeline.job"]["id"],
                failureDetails={
                    'type': 'JobFailed',
                    'message': 'failed'
                }
            )
    else:
        print("Assuming being run from SSM Automation")